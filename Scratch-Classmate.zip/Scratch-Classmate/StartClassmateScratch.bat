Scratch.exe ClassmateScratch.image
